#ifndef SO_H_
#define SO_H_

	void soInit (void);
	void soWrite(int value);

#endif
